//
//  ViewController.swift
//  universoenverso
//
//  Created by A4-iMAC03 on 16/02/2021.
//

import UIKit
import ARKit

class ViewController: UIViewController {

    @IBOutlet weak var sceneView: ARSCNView!
    let configuration = ARWorldTrackingConfiguration()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.sceneView.debugOptions = [ARSCNDebugOptions.showWorldOrigin]
        
        self.sceneView.autoenablesDefaultLighting = true
        
        self.sceneView.session.run(configuration)
        
        
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
           
        let sunny = planet(geometry: SCNSphere(radius: 0.35), diffuse: UIImage(named: "sol diffuse"), specular: nil, emission: nil, normal: nil, position: SCNVector3(0,0,-1))
        
        
        let actionsun = self.rotation(time: 8)
        sunny.runAction(actionsun)
        
        /*
        //el lorenzo
        let sun = SCNNode(geometry: SCNSphere(radius: 0.35))
        sun.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "sol diffuse")
        
        sun.position = SCNVector3(0,0,-1)
      */
        
        self.sceneView.scene.rootNode.addChildNode(sunny)
        
        let pachamama = planet(geometry: SCNSphere(radius: 0.2), diffuse: UIImage(named: "tierra dia"), specular: UIImage(named: "tierra specular"), emission: UIImage(named: "tierra nubes"), normal: UIImage(named: "tierra normal"), position: SCNVector3 (1.2,0,0))
        
        
        /*
        //nodo tierra
        let tierraNode = SCNNode()
        tierraNode.geometry = SCNSphere(radius: 0.2)
        tierraNode.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "tierra dia")
        tierraNode.geometry?.firstMaterial?.specular.contents = UIImage(named: "tierra specular")
        
        tierraNode.geometry?.firstMaterial?.emission.contents = UIImage(named: "tierra nubes")
        tierraNode.geometry?.firstMaterial?.normal.contents = UIImage(named: "tierra normal")

        tierraNode.position = SCNVector3 (1.2,0,0)
        */
        
        
        
        
        
        //rotate earth
        /*
        let action = SCNAction.rotateBy(x: 0, y: CGFloat(360.degreesToRadians), z: 0, duration: 8)
        let forever = SCNAction.repeatForever(action)
        pachamama.runAction(forever)
        */
        
        
        
        
        let padreTierra = SCNNode()
        padreTierra.position = sunny.position
        self.sceneView.scene.rootNode.addChildNode(padreTierra)
        padreTierra.addChildNode(pachamama)
        
        let actionPadreTierra = rotation(time: 14)
        padreTierra.runAction(actionPadreTierra)
        
        
    }
    
    //funcion planet generator
    func planet(geometry: SCNGeometry,diffuse:UIImage?,specular:UIImage?,emission:UIImage?, normal:UIImage?,position: SCNVector3)->SCNNode {
        
        
        let planet = SCNNode(geometry: geometry)
        planet.geometry?.firstMaterial?.diffuse.contents = diffuse
        planet.geometry?.firstMaterial?.specular.contents = specular
        planet.geometry?.firstMaterial?.emission.contents = emission
        planet.geometry?.firstMaterial?.normal.contents = normal
        planet.position = position
        
        return planet
        
    }
    
    //funcion turn on
    func rotation(time: TimeInterval)-> SCNAction{
        let rotation = SCNAction.rotateBy(x: 0, y: CGFloat(360.degreesToRadians), z: 0, duration: time)
        let foreverRotate = SCNAction.repeatForever(rotation)
        return foreverRotate
    }
    


}

//pasar de grados a radiones
extension Int {
    var degreesToRadians : Double {return Double(self) * .pi/180}
}

