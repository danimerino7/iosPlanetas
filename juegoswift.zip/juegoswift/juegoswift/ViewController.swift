//
//  ViewController.swift
//  juegoswift
//
//  Created by A4-iMAC03 on 17/02/2021.
//

import UIKit
import ARKit
import Each

class ViewController: UIViewController {

    @IBOutlet weak var playBtn: UIButton!
    
    @IBOutlet weak var labelTemp: UILabel!
    
    var temp = Each(1).seconds
    var cuenta = 10
    
    @IBOutlet weak var escena: ARSCNView!
    
    let configuration = ARWorldTrackingConfiguration()
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        self.escena.session.run(configuration)
        
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        self.escena.addGestureRecognizer(tapGestureRecognizer)
        
        
    }
    
    

    @IBAction func play(_ sender: Any) {
        addNode()
        self.setTiempo()
        self.playBtn.isEnabled = false
        
    }
    func setTiempo(){
        
        self.temp.perform{
            ()-> NextStep in
            self.cuenta -= 1
            self.labelTemp.text = String(self.cuenta)
            
            if self.cuenta == 0 {
                self.labelTemp.text = "lost"
                return .stop
            }
            return .continue
        }
    }
    
    
    @objc func handleTap(sender:UITapGestureRecognizer){
        
        let sceneViewTappedOn = sender.view as! SCNView
        let touchCoor = sender.location(in: sceneViewTappedOn) //coordenadas del tap
        let hitTest = sceneViewTappedOn.hitTest(touchCoor)
        
        if hitTest.isEmpty {
            print("no te tocas")
        }else{
            
            let results = hitTest.first!
            let name = results.node.name
            print("te pico la  \(name!)")
            
            let node = results.node
            if node.animationKeys.isEmpty , name != nil{
                SCNTransaction.begin()
                self.animateNode(node: node)
                SCNTransaction.completionBlock = {
                    node.removeFromParentNode()
                    self.addNode()
                    self.resetTime()
                }
                SCNTransaction.commit()
            }
            
            
        }
    }
    
    
    func resetTime(){
        self.cuenta = 10
        self.labelTemp.text = String(self.cuenta)
        self.playBtn.isEnabled = true
    }
    
    
    func addNode()  {
        let node = SCNNode(geometry: SCNBox(width: 0.2, height: 0.2, length: 0.2, chamferRadius: 0))
        node.name = "Kubo del getafe"
        node.position = SCNVector3(0, 0, -1)
        self.escena.scene.rootNode.addChildNode(node)
        
        let node2 = SCNNode(geometry: SCNPyramid(width: 0.2, height: 0.2, length: 0.2))
        node2.name = "Kubo-piramide cuando estaba en el villareal"
        node2.position = SCNVector3(-1, 0, -1)
        self.escena.scene.rootNode.addChildNode(node2)
        
        let medusaEscena = SCNScene(named: "SceneKitAssetCatalog.scnassets/Jellyfish.scn")
        
        let medusa = medusaEscena?.rootNode.childNode(withName: "jellyfish", recursively: false)
        
        medusa?.position = SCNVector3(0, 0.05, -2)
        
        medusa?.name = "Medusa"
        self.escena.scene.rootNode.addChildNode(medusa!)
        
        
    }
    
    func animateNode(node:SCNNode){
        let spin = CABasicAnimation(keyPath: "position")
        spin.fromValue = node.presentation.position //posiicion inicial
        spin.toValue = SCNVector3(node.presentation.position.x,node.presentation.position.y,node.presentation.position.z - 1)
        spin.duration = 1.07
        spin.autoreverses = true
        spin.repeatCount = 5
        node.addAnimation(spin, forKey: "position")
        
 
        
    }
    
}

